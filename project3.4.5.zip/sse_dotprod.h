#ifndef SSE_DOTPROD_H
#define SSE_DOTPROD_H

float sse_dotprod(float x[], float y[], int n);

#endif // SSE_DOTPROD_H
