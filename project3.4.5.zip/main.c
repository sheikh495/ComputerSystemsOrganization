#include <stdio.h>
#include "generate_result_html.h"

int main() {
    // Call the function to generate result_htm.html
    generate_result_html();

    return 0;
}
