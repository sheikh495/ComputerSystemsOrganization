#ifndef DOTPROD_H
#define DOTPROD_H

float dotprod(float x[], float y[], int n);

#endif // DOTPROD_H
