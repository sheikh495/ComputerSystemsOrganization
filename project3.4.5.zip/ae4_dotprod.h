#ifndef AE4_DOTPROD_H
#define AE4_DOTPROD_H

float ae4_dotprod(float x[], float y[], int n);

#endif // AE4_DOTPROD_H
