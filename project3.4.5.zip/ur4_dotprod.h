#ifndef UR4_DOTPROD_H
#define UR4_DOTPROD_H

float ur4_dotprod(float x[], float y[], int n);

#endif // UR4_DOTPROD_H
