#ifndef GENERATE_RESULT_HTML_H
#define GENERATE_RESULT_HTML_H

// Function declaration
void generate_result_html();

#endif // GENERATE_RESULT_HTML_H
